import { createContext } from "react";

export const VideoDataContext=createContext();